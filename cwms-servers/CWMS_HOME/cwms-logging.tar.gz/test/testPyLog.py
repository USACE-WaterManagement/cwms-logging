import sys
import os
cwms_home_path = os.getenv('CWMS_HOME')
sys.path.append("{}/bin".format(cwms_home_path))
from loggingSetup import setup_logging
import logging
setup_logging()
# Now print statements will go to logging
print("Print Test")
logger = logging.getLogger("Test Python Logging")
logger.info("Logging Test Info")
logger.error("Logging Test Error")
logger.warning("Logging Test Warning")
logger.debug("Logging Test Debug")
logger.critical("Logging Test Critical")